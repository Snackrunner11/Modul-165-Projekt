package services;

import models.Order;
import repositories.OrderRepository;

import java.util.List;

public class OrderService {
    private final OrderRepository orderRepository;

    public OrderService() {
        this.orderRepository = new OrderRepository();
    }

    // Bestellung hinzufügen
    public void addOrder(Order order) {
        orderRepository.insertOrder(order);
        System.out.println("Bestellung erfolgreich hinzugefügt: " + order.getOrderNumber());
    }

    // Alle Bestellungen abrufen
    public List<Order> getAllOrders() {
        List<Order> orders = orderRepository.findAllOrders();
        if (orders.isEmpty()) {
            System.out.println("Keine Bestellungen in der Datenbank gefunden.");
        }
        return orders;
    }

    // Bestellung anhand der ID finden
    public Order getOrderById(String id) {
        Order order = orderRepository.findOrderById(id);
        if (order == null) {
            System.out.println("Keine Bestellung mit der ID gefunden: " + id);
        }
        return order;
    }

    // Bestellung aktualisieren
    public void updateOrder(Order order) {
        boolean updated = orderRepository.updateOrder(order);
        if (updated) {
            System.out.println("Bestellung erfolgreich aktualisiert: " + order.getOrderNumber());
        } else {
            System.out.println("Bestellung konnte nicht aktualisiert werden.");
        }
    }

    // Bestellung löschen
    public void deleteOrder(String id) {
        boolean deleted = orderRepository.deleteOrder(id);
        if (deleted) {
            System.out.println("Bestellung erfolgreich gelöscht.");
        } else {
            System.out.println("Bestellung konnte nicht gelöscht werden.");
        }
    }
}

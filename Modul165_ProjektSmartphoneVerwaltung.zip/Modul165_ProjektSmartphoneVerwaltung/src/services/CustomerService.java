package services;

import models.Customer;
import repositories.CustomerRepository;

import java.util.List;

public class CustomerService {
    private final CustomerRepository customerRepository;

    public CustomerService() {
        this.customerRepository = new CustomerRepository();
    }

    // Kunde hinzufügen
    public void addCustomer(Customer customer) {
        customerRepository.insertCustomer(customer);
        System.out.println("Kunde erfolgreich hinzugefügt: " + customer.getFirstName() + " " + customer.getLastName());
    }

    // Alle Kunden abrufen
    public List<Customer> getAllCustomers() {
        List<Customer> customers = customerRepository.findAllCustomers();
        if (customers.isEmpty()) {
            System.out.println("Keine Kunden in der Datenbank gefunden.");
        }
        return customers;
    }

    // Kunde anhand der ID finden
    public Customer getCustomerById(String id) {
        Customer customer = customerRepository.findCustomerById(id);
        if (customer == null) {
            System.out.println("Kein Kunde mit der ID gefunden: " + id);
        }
        return customer;
    }

    // Kunde aktualisieren
    public void updateCustomer(Customer customer) {
        boolean updated = customerRepository.updateCustomer(customer);
        if (updated) {
            System.out.println("Kunde erfolgreich aktualisiert: " + customer.getFirstName() + " " + customer.getLastName());
        } else {
            System.out.println("Kunde konnte nicht aktualisiert werden.");
        }
    }

    // Kunde löschen
    public void deleteCustomer(String id) {
        boolean deleted = customerRepository.deleteCustomer(id);
        if (deleted) {
            System.out.println("Kunde erfolgreich gelöscht.");
        } else {
            System.out.println("Kunde konnte nicht gelöscht werden.");
        }
    }
}

package services;

import models.Smartphone;
import repositories.SmartphoneRepository;

import java.util.List;

public class SmartphoneService {
    private final SmartphoneRepository smartphoneRepository;

    public SmartphoneService() {
        this.smartphoneRepository = new SmartphoneRepository();
    }

    // Create
    public void addSmartphone(Smartphone smartphone) {
        smartphoneRepository.insertSmartphone(smartphone);
    }

    // Read: Alle Smartphones
    public List<Smartphone> getAllSmartphones() {
        return smartphoneRepository.findAllSmartphones();
    }

    // Read: Smartphone nach ID
    public Smartphone getSmartphoneById(String id) {
        return smartphoneRepository.findSmartphoneById(id);
    }

    // Update
    public void updateSmartphone(String id, Smartphone updatedSmartphone) {
        smartphoneRepository.updateSmartphone(id, updatedSmartphone);
    }

    // Delete
    public void deleteSmartphone(String id) {
        smartphoneRepository.deleteSmartphone(id);
    }
}

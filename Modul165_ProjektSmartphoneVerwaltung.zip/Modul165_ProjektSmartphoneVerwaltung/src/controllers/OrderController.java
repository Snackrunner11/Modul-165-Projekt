package controllers;

import models.Customer;
import models.Order;
import models.OrderItem;
import models.Smartphone;
import services.CustomerService;
import services.OrderService;
import services.SmartphoneService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class OrderController {
    private final OrderService orderService;
    private final CustomerService customerService;
    private final SmartphoneService smartphoneService;

    public OrderController() {
        this.orderService = new OrderService();
        this.customerService = new CustomerService();
        this.smartphoneService = new SmartphoneService();
    }

    public void manageOrders() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Bestellverwaltung ---");
            System.out.println("1. Bestellung hinzufügen");
            System.out.println("2. Alle Bestellungen anzeigen");
            System.out.println("3. Bestellung löschen");
            System.out.println("0. Zurück");
            System.out.print("Wähle eine Option: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Zeilenumbruch einlesen

            switch (choice) {
                case 1 -> addOrder();
                case 2 -> showAllOrders();
                case 3 -> deleteOrder();
                case 0 -> System.out.println("Zurück zum Hauptmenü.");
                default -> System.out.println("Ungültige Eingabe. Bitte versuche es erneut.");
            }
        } while (choice != 0);
    }

    private void addOrder() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Kunden-ID eingeben: ");
        String customerId = scanner.nextLine();
        Customer customer = customerService.getCustomerById(customerId);

        if (customer == null) {
            System.out.println("Kunde nicht gefunden!");
            return;
        }

        List<OrderItem> items = new ArrayList<>();
        double total = 0.0;
        String continueAdding = "ja"; // Initialisiere mit "ja"

        do {
            System.out.print("Smartphone-ID eingeben: ");
            String smartphoneId = scanner.nextLine();
            Smartphone smartphone = smartphoneService.getSmartphoneById(smartphoneId);

            if (smartphone == null) {
                System.out.println("Smartphone nicht gefunden!");
                continue;
            }

            System.out.print("Menge: ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Zeilenumbruch einlesen

            double itemTotal = smartphone.getPrice() * quantity;
            total += itemTotal;

            items.add(new OrderItem(smartphone, smartphone.getPrice(), quantity));

            System.out.print("Weiteres Smartphone hinzufügen? (ja/nein): ");
            continueAdding = scanner.nextLine();
        } while (continueAdding.equalsIgnoreCase("ja"));

        System.out.print("Bestellnummer eingeben: ");
        String orderNumber = scanner.nextLine();

        Order order = new Order(orderNumber, new Date(), customer, items, total);
        orderService.addOrder(order);
    }

    private void showAllOrders() {
        List<Order> orders = orderService.getAllOrders();
        if (orders.isEmpty()) {
            System.out.println("Keine Bestellungen in der Datenbank gefunden.");
        } else {
            System.out.println("\n--- Liste der Bestellungen ---");
            for (Order order : orders) {
                System.out.println(order);
            }
        }
    }

    private void deleteOrder() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Gib die ID der Bestellung ein, die gelöscht werden soll: ");
        String id = scanner.nextLine();
        orderService.deleteOrder(id);
    }
}

package controllers;

import java.util.Scanner;

public class MainController {
    private final SmartphoneController smartphoneController;

    public MainController() {
        this.smartphoneController = new SmartphoneController();
    }

    public void start() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n--- Admin-Tool für den Online-Shop ---");
            System.out.println("1. Smartphones verwalten");
            System.out.println("0. Beenden");
            System.out.print("Wähle eine Option: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Zeilenumbruch einlesen

            switch (choice) {
                case 1 -> smartphoneController.manageSmartphones();
                case 0 -> System.out.println("Programm beendet.");
                default -> System.out.println("Ungültige Eingabe. Bitte versuche es erneut.");
            }
        } while (choice != 0);
    }
}

package Main;

import com.mongodb.client.MongoDatabase;
import repositories.MongoDBConnection;

public class TestDatabaseConnection {
    public static void main(String[] args) {
        try {
            MongoDatabase database = MongoDBConnection.getDatabase();
            System.out.println("Erfolgreich mit der Datenbank verbunden: " + database.getName());
        } catch (Exception e) {
            System.err.println("Fehler bei der Verbindung: " + e.getMessage());
        }
    }
}
